

<!DOCTYPE html>
<html lang="fr">
<head>
	<title>STUDENTS ATTENDANCE </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="css/styles.css">
    
</head>
<body style="background-color:green;">


<br><br>
<div class="col-md-5 p-0 row-cols-1 container justify-content-center">
  <div class="text-primary col bg-primary text-light pt-auto pb-auto h3" style="height: 35px; width: 60%; text-align: center; color:black;margin:0px;" >
    Veillez vous identifiez
  </div>
  <div class="container row d-flex flex-row justify-content-center">

    <div class="admin-form  p-4">
    <div id="message"></div>
      <form class="" action="traitement.php" method="POST" id="attendance">
        <div id="message"></div>
            <div class="form-group  mb-3">
              <label for="" class="form-label text-bold text-primary"> Votre Email:</label>
              <input type="text" name="email" id="email" value="" class="form-control " autocomplete="off">
            </div>
            <div class="form-group mb-3">
              <label for="" class="form-label text-bold text-primary">Mot de Passe:</label>
              <input type="password" name="mdp" id="mdp" value="" class="form-control" autocomplete="off">
            </div>
            <input type="submit" class="btn btn-primary" name="submit" value="connexion"><br>
      </form>
  </div>



</div>
<!-- <div class="col-md-8 row  justify-content-center " id="form">
  <?php if (isset($message) and !empty($message)) {?>

    <div class="alert alert-success alert-dismissible fade show " role ="alert" id="alert" >
      <?=$message?>
      <button type="button" class="close" data-dismiss="alert" aria-label="close" >&times;</button>

    </div>
    <?php  } ?>
</div> -->
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="ajax.js"></script>
</body>
</html>

 