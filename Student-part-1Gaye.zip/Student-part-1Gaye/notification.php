

<!DOCTYPE html>
<html lang="fr">
<head>
	<title>STUDENTS ATTENDANCE </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="css/styles.css">
    
</head>
<body style="background-color:green;">


<br><br>
     <div class="container row d-flex flex-row justify-content-center p-10">

  <div class="admin-form shadow p-4">

	<div class=" card bg-light">
	<div class="card-body text center">
		<div class="card-text">
			<h2>
	<?php echo"Merci d'avoir signé votre presence en ce jour : " . date("d-m-Y") . " à " . date("H:i:s") ;?>
	<br><br>
	<a href="index.php" class="btn btn-primary pl-10">ok</a>
	</h1>
    </div>
    </div>
  
    </div>
    </div>
    </div>


<br><br>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/auth.js"></script>
</body>
</html>

 



<!-- 

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
    alert("email ou mot de pass invalide");
    </script>
    


  -->