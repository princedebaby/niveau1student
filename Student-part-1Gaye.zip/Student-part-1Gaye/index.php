<!DOCTYPE html>
<html lang="fr">
<head>
	<title>STUDENTS ATTENDANCE </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="css/styles.css">
    
</head>
<body style="background-color:green;">

<div class="col-md-5 p-0 row-cols-1 container justify-content-center" style="margin-bottom: ">


<div class="container admin-form shadow p-4">
	<div class="row">
	        <div class="col-md-6 offset-3">
             
		<form  id="register-form" method="POST" enctype="multipart/form-data">
                                <div id="message"></div>
                     
                         <div class="text-primary col  text-light pt-auto pb-auto h3" style="height: 50px; text-align: center;" >
                                  INSCRIPTION
                        </div>        

                    <div class="form-group">
                            <label for="" class="form-label text-bold text-primary">Nom et prenom</label>
                            <input type="text" name="nom" id="fullname" class="form-control" placeholder="votre nom et prenom">
                    </div>

                    <div class="form-group">
                            <label for="" class="form-label text-bold text-primary">E-mail</label>
                             <input type="email" name="email" id="email" class="form-control" placeholder="votre Adresse mail"> 
                    </div>

                    <div class="form-group">
                            <label for="" class="form-label text-bold text-primary">Mot de passe</label>
                            <input type="password" name="mdp" id="mdp" class="form-control" placeholder="votre Mot de passe">
                    </div>

                    <div class="form-group">
                            <label for="" class="form-label text-bold text-primary">Mot de passe</label>
                            <input type="password" name="mdp2" id="mdp_c" class="form-control" placeholder="Reprendre le mot de passe">
                    </div>

                      <button type="submit" class=" btn btn-primary" id="mysubmit" name="send" value="send"> Valider </button> 
                       
		</form>
			
		</div>
		<div> <a href="signature.php">Si vous etes déja enregistrez , Cliquez ici pour marquervotre presence</a> </div>
	</div>
	</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" src="ajax.js"></script>
</body>
</html>

 